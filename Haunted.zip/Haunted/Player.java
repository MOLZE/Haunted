import java.util.ArrayList;

/**
 * Escreva uma descrição da classe Player aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Player
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    
    private int maximumWeight = 3, currentWeight = 0;
    private ArrayList<Item> invPlayer = new ArrayList<>();
    private Room currentRoom;
    
    /**
     * Construtor para objetos da classe Player
     */
    public Player(Room room)
    {
        // inicializa variáveis de instância
        currentRoom = room;
    }
    public void getItem(Item item){
        if(item.giveWeight() + currentWeight > maximumWeight){
            System.out.println("You can't carry items anymore...");
        }else{
            invPlayer.add(item);
            currentWeight = item.giveWeight() + currentWeight;
        }
    }
    public void dropItem(){
        currentWeight = currentWeight - invPlayer.get(0).giveWeight();
        invPlayer.remove(0);
    }
}
